class Common {
  final String baseUrl = "https://api.thecatapi.com/v1";
  final String baseUrlDetail = "https://api.thecatapi.com/v1/images/";
  final String apiKey = 'live_wO9IiJwLFyZYIIhyoHFl6XQ87Y6zMBQ8VOTdTIQbwUhRRb1aaOsIEnxcL2mSyWm3';
  final String baseUrlImageCats = 'https://cdn2.thecatapi.com/images/';
  final String baseUrlLoadingCats = 'https://img.icons8.com/cotton/256/null/cat--v2.png';
  final String baseUrlLogoCat = 'https://img.icons8.com/cotton/256/null/cat--v2.png';
}
