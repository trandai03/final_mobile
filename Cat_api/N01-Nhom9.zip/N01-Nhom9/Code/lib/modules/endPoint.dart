class EndPoints {
  final String breeds = '/breeds';
}
